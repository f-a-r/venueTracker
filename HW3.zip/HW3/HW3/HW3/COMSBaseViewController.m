//
//  COMSBaseViewController.m
//  HW3
//
//  Created by Farzaneh Motahari on 4/5/14.
//  Copyright (c) 2014 Shahriar. All rights reserved.
//



#import "COMSBaseViewController.h"
#import <COMSMapManager/COMSMapManager.h>
#import "TabBarViewController.h"

@interface COMSBaseViewController ()

@property (weak, nonatomic) IBOutlet MKMapView *mapView;

@end

@implementation COMSBaseViewController


#pragma mark - Loading methods
/*
 Automatically called by the view controller
 */
-(void)awakeFromNib{
}

/*
 Automatically called by the view controller
 */
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //make ourselves the delegate of the textfield so we can be notified of changes by it
    self.inputTextField.delegate = self;
    
    //Most of NSLogs are for my own chechking of the code
    NSLog(@"parent view controller: %@", [self.parentViewController class]);
    
    TabBarViewController *parent = (TabBarViewController*)self.parentViewController;
    //result = location that was sent from searchviewcontroller to parent of this view controller
    NSMutableArray *results = parent.locations;
    
    //zooming map to current location
    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(parent.coord, 2000, 2000);
    [_mapView setRegion:[_mapView regionThatFits:region] animated:YES];
    
    for (NSDictionary *entry in results) {
        NSDictionary *geometry = [entry valueForKey:@"geometry"];
        NSDictionary *location = [geometry valueForKey:@"location"];
        NSString *lat = [location valueForKey:@"lat"];
        NSString *lng = [location valueForKey:@"lng"];
        NSString *name = [entry valueForKey:@"name"];
        NSString *adrs = [entry valueForKey:@"vicinity"];
        
        NSLog(@"address is:%@",adrs);
        
        double latitude = [lat doubleValue];
        double longitude = [lng doubleValue];
        
        Pin *p = [[Pin alloc] initWithCoordinate:CLLocationCoordinate2DMake(latitude, longitude) title:name subtitle:adrs];
        [_mapView addAnnotation:p];
        
        NSLog(@"%@",entry);
    }
}

#pragma mark - Gesture recognizers
/*
 Actions when a certain view is tapped. In this case I added this recognizer to the main view (self.view) so that the keyboard will dismiss when the screen is tapped
 */
- (IBAction)screenTapped:(UITapGestureRecognizer *)sender {
    
    //This is how I found this works: The textfield has a property called first responder. The keyboard is this textfields accessory view. When the textfield is in first responder mode, it means it is the primary focus on the screen (the textfield cursor is blinking, keyboard is up). To dismiss the keyboard, I tell it to resignFirstResponder status
    if (self.inputTextField.isFirstResponder) {
        [self.inputTextField resignFirstResponder];
    }
}


@end








