//
//  COMSBaseViewController.h
//  HW3

//  Created by Farzaneh Motahari on 4/5/14.
//  Copyright (c) 2014 Shahriar. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import "Pin.h"
#import "SearchViewController.h"

//import the class where the CLLocationManagerDelegate protocol is implemented
@import CoreLocation;


@interface COMSBaseViewController : UIViewController<UITextFieldDelegate>

//connect our view controllers to the UIKit items on the storyboard
@property (strong, nonatomic) IBOutlet UITextField *inputTextField;
@property (strong, nonatomic) IBOutlet UILabel *display;

@end
