//
//  TabBarViewController.m
//  HW3
//
//  Created by Farzaneh Motahari on 4/5/14.
//  Copyright (c) 2014 Shahriar. All rights reserved.
//

#import "TabBarViewController.h"

@interface TabBarViewController ()

@end

@implementation TabBarViewController

@synthesize locations = _locations;
@synthesize coord = _coord;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    //some extra code I found for checking system version control ie. ios 7 and etc
    [super viewDidLoad];
    NSArray *ver = [[UIDevice currentDevice].systemVersion componentsSeparatedByString:@"."];
    if([[ver objectAtIndex:0]intValue] >= 7){
        self.edgesForExtendedLayout = UIRectEdgeNone;
    }
    [[self.tabBar.items objectAtIndex:0] setTitle:@"Map"];
    [[self.tabBar.items objectAtIndex:1] setTitle:@"List"];
    [[self.tabBar.items objectAtIndex:2] setTitle:@"Favorites"];
    self.title = @"Map";
    // Do any additional setup after loading the view.
}

- (void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item{
    self.title = item.title;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
