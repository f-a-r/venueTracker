//
//  LocationDetailViewController.m
//  HW3
//
//  Created by Farzaneh Motahari on 4/5/14.
//  Copyright (c) 2014 Shahriar. All rights reserved.
//

#import "LocationDetailViewController.h"
#import <COMSMapManager/COMSMapManager.h>
#import <CoreLocation/CoreLocation.h>

#define FAVORITES @"favorites"
#define UNFAVORITE @"Un-favorite"
#define FAVORITE @"Favorite"

@interface LocationDetailViewController ()

@property (weak, nonatomic) IBOutlet MKMapView *detailMapView;

@end

@implementation LocationDetailViewController

@synthesize location = _location;
@synthesize imageView = _imageView;
@synthesize nameLabel = _nameLabel;
@synthesize addressLabel = _addressLabel;
@synthesize priceLevelLabel = _priceLevelLabel;
@synthesize ratingLabel = _ratingLabel;
@synthesize detailMapView = _detailMapView;
@synthesize favoriteButton = _favoriteButton;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    //These codes are all showing the information of the selected item from the tbaleView together with this locations pin on the
    //map. The data of this location was already set in LocationTableViewController when the row corresponding to this place was
    //selected
    NSData *yourData = [[NSMutableData alloc]initWithContentsOfFile:[self getFilePath]];
    if(yourData){
        NSKeyedUnarchiver *unarchiver = [[NSKeyedUnarchiver alloc] initForReadingWithData:yourData];
        NSArray *favoritesArray = [unarchiver decodeObjectForKey:FAVORITES];
        NSLog(@"%@!", favoritesArray);
    } else {
        NSLog(@"no");
    }
    //Checking whether item selected is already in favorites or not so to set the button lable to either favorite or un-favorite!
    if([[NSMutableData alloc]initWithContentsOfFile:[self getFilePath]]){
        NSData *favoritesData = [[NSMutableData alloc]initWithContentsOfFile:[self getFilePath]];
        NSKeyedUnarchiver *unarchiver = [[NSKeyedUnarchiver alloc] initForReadingWithData:favoritesData];
        NSArray *favoritesArray = [unarchiver decodeObjectForKey:FAVORITES];
        [unarchiver finishDecoding];
        NSLog(@"favorites: %@", favoritesArray);
        for (NSDictionary *location in favoritesArray) {
            if([[location objectForKey:@"id"]isEqualToString:[self.location objectForKey:@"id"]]){
                [self.favoriteButton setTitle:UNFAVORITE forState:UIControlStateNormal];
                break;
            }
        }
    }
    
    NSArray *ver = [[UIDevice currentDevice].systemVersion componentsSeparatedByString:@"."];
    if([[ver objectAtIndex:0]intValue] >= 7){
        self.edgesForExtendedLayout = UIRectEdgeNone;
    }
    //setting the fields to appropriate values
    NSLog(@"location: %@", self.location);
    NSURL *imageURL = [[NSURL alloc]initWithString:[self.location objectForKey:@"icon"]];
    [self.imageView setImage:[UIImage imageWithData:[NSData dataWithContentsOfURL:imageURL]]];
    [self.nameLabel setText:[self.location objectForKey:@"name"]];
    [self.addressLabel setText:[self.location objectForKey:@"vicinity"]];
    
    
    NSString *priceLevelString = [NSString stringWithFormat:@"price level: %@", [[self.location objectForKey:@"price_level"]stringValue]];
    [self.priceLevelLabel setText:priceLevelString];
    
    NSString *ratingString = [NSString stringWithFormat:@"rating: %@", [[self.location objectForKey:@"rating"]stringValue]];
    [self.ratingLabel setText:ratingString];
    
    NSDictionary *geometry = [self.location valueForKey:@"geometry"];
    NSDictionary *entry = [geometry valueForKey:@"location"];
    NSString *lat = [entry valueForKey:@"lat"];
    NSString *lng = [entry valueForKey:@"lng"];
    double latitude = [lat doubleValue];
    double longitude = [lng doubleValue];
    NSString *name = [entry valueForKey:@"name"];
    NSString *adrs = [entry valueForKey:@"vicinity"];
    NSLog(@"lat:%@",lat);
    NSLog(@"long:%@",lng);
    
    Pin *p = [[Pin alloc] initWithCoordinate:CLLocationCoordinate2DMake(latitude, longitude) title:name subtitle:adrs];
    [self.detailMapView addAnnotation:p];
    CLLocationCoordinate2D userLocation = CLLocationCoordinate2DMake(latitude, longitude);
    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(userLocation, 2000, 2000);
    [self.detailMapView setRegion:[self.detailMapView regionThatFits:region] animated:YES];
}

- (IBAction)favoriteButtonPressed:(id)sender{
    //save this to the favorites list
    NSData *favoritesData = [[NSMutableData alloc]initWithContentsOfFile:[self getFilePath]];
    NSMutableArray *newFavorites = [[NSMutableArray alloc]init];
    
    if(!favoritesData){
        [newFavorites addObject:self.location];
    } else {
        NSData *favoritesData = [[NSMutableData alloc]initWithContentsOfFile:[self getFilePath]];
        NSKeyedUnarchiver *unarchiver = [[NSKeyedUnarchiver alloc] initForReadingWithData:favoritesData];
        NSArray *oldFavorites = [unarchiver decodeObjectForKey:FAVORITES];
        [unarchiver finishDecoding];
        if([self.favoriteButton.titleLabel.text isEqualToString:FAVORITE]){
            for (NSDictionary *location in oldFavorites) {
                [newFavorites addObject:location];
            }
            [newFavorites addObject:self.location];
            [self.favoriteButton setTitle:UNFAVORITE forState:UIControlStateNormal];
        } else {
            for (NSDictionary *location in oldFavorites) {
                if(![[location objectForKey:@"id"]isEqualToString:[self.location objectForKey:@"id"]]){
                    [newFavorites addObject:location];
                }
            }
            [self.favoriteButton setTitle:FAVORITE forState:UIControlStateNormal];
        }
    }
    NSMutableData *yourData = [[NSMutableData alloc] init];
    NSKeyedArchiver *archiver = [[NSKeyedArchiver alloc] initForWritingWithMutableData:yourData];
    [archiver encodeObject:newFavorites forKey:FAVORITES];
    [archiver finishEncoding];
    NSLog(@"data: %@", yourData);
    [yourData writeToFile:[self getFilePath] atomically:YES];
}

- (NSString*)getFilePath{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    return [documentsDirectory stringByAppendingPathComponent:FAVORITES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
