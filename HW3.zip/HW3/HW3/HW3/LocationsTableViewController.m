//
//  LocationsTableViewController.m
//  HW3
//
//  Created by Farzaneh Motahari on 4/5/14.
//  Copyright (c) 2014 Shahriar. All rights reserved.
//

#import "LocationsTableViewController.h"
#import "TabBarViewController.h"
#import "LocationDetailViewController.h"

@interface LocationsTableViewController ()

@end

@implementation LocationsTableViewController

@synthesize locations = _locations;
@synthesize tableView = _tableView;

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    NSLog(@"parent view controller: %@", [self.parentViewController class]);
    
    TabBarViewController *parent = (TabBarViewController*)self.parentViewController;
    //getting the locations from the parent (TabBarViewController) of this viewController
    self.locations = parent.locations;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.locations count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"LocationCell" forIndexPath:indexPath];
    
    // Configure the cell...
    NSDictionary *entry = [self.locations objectAtIndex:indexPath.row];
//    NSDictionary *geometry = [entry valueForKey:@"geometry"];
//    NSDictionary *location = [geometry valueForKey:@"location"];
//    NSString *lat = [location valueForKey:@"lat"];
//    NSString *lng = [location valueForKey:@"lng"];
    NSString *name = [entry valueForKey:@"name"];
    NSString *adrs = [entry valueForKey:@"vicinity"];
    
    NSLog(@"address is:%@",adrs);
    
//    double latitude = [lat doubleValue];
//    double longitude = [lng doubleValue];
    
    NSLog(@"%@",entry);
    
    [cell.textLabel setText:name];
    [cell.detailTextLabel setText:adrs];
    
    return cell;
}
//send the entry of the delectedrow to LocationDetailViewController for more detailed information of the selected place
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSLog(@"you clicked a row");
    NSDictionary *entry = [self.locations objectAtIndex:indexPath.row];
    LocationDetailViewController *locationVC = [self.storyboard instantiateViewControllerWithIdentifier:@"LocationDetail"];
    [locationVC setLocation:entry];
    [self.navigationController pushViewController:locationVC animated:YES];
}



@end
