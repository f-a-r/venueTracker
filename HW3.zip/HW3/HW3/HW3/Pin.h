//
//  Pin.h
//  HW3
//
//  Created by Farzaneh Motahari on 4/5/14.
//  Copyright (c) 2014 Shahriar. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>

@interface Pin : NSObject <MKAnnotation> {
    CLLocationCoordinate2D coordinate;
    NSString *title;
    NSString *subtitle;
}

-(id)init;
-(id)initWithCoordinate:(CLLocationCoordinate2D)coord title:(NSString *)name subtitle:(NSString *)adrs;

@end
