//
//  FavoritesViewController.m
//  HW3
//
//  Created by Farzaneh Motahari on 4/5/14.
//  Copyright (c) 2014 Shahriar. All rights reserved.
//

#import "FavoritesViewController.h"
#import "LocationDetailViewController.h"

#define FAVORITES @"favorites"

@interface FavoritesViewController ()

@end

@implementation FavoritesViewController

@synthesize tableView = _tableView;
@synthesize favorites = _favorites;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.title = @"Favorites";
    
    NSData *favoritesData = [[NSMutableData alloc]initWithContentsOfFile:[self getFilePath]];
    if(favoritesData){
        NSKeyedUnarchiver *unarchiver = [[NSKeyedUnarchiver alloc] initForReadingWithData:favoritesData];
        self.favorites = [unarchiver decodeObjectForKey:FAVORITES];
        [unarchiver finishDecoding];
        NSLog(@"\n \n \n ______FAVORITES________:\n %@", self.favorites);
    } else {
        [[[UIAlertView alloc]initWithTitle:@"No Favorites" message:@"You do not have any favorites saved." delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil]show];
    }
    [self.tableView reloadData];
}

- (void)viewDidAppear:(BOOL)animated{
    NSData *favoritesData = [[NSMutableData alloc]initWithContentsOfFile:[self getFilePath]];
    if(favoritesData){
        NSKeyedUnarchiver *unarchiver = [[NSKeyedUnarchiver alloc] initForReadingWithData:favoritesData];
        self.favorites = [unarchiver decodeObjectForKey:FAVORITES];
        [unarchiver finishDecoding];
    }
    [self.tableView reloadData];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    //We only have one section in TableView
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(self.favorites){
        return [self.favorites count];
    } else {
        return 0;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"FavoriteCell" forIndexPath:indexPath];
    
    // Configure the cell...
    NSDictionary *entry = [self.favorites objectAtIndex:indexPath.row];
    //    NSDictionary *geometry = [entry valueForKey:@"geometry"];
    //    NSDictionary *location = [geometry valueForKey:@"location"];
    //    NSString *lat = [location valueForKey:@"lat"];
    //    NSString *lng = [location valueForKey:@"lng"];
    NSString *name = [entry valueForKey:@"name"];
    NSString *adrs = [entry valueForKey:@"vicinity"];
    
    NSLog(@"address is:%@",adrs);
    
    //    double latitude = [lat doubleValue];
    //    double longitude = [lng doubleValue];
    
    NSLog(@"%@",entry);
    
    [cell.textLabel setText:name];
    [cell.detailTextLabel setText:adrs];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSDictionary *entry = [self.favorites objectAtIndex:indexPath.row];
    LocationDetailViewController *locationVC = [self.storyboard instantiateViewControllerWithIdentifier:@"LocationDetail"];
    [locationVC setLocation:entry];
    [self.navigationController pushViewController:locationVC animated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSString*)getFilePath{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    return [documentsDirectory stringByAppendingPathComponent:FAVORITES];
}


@end
