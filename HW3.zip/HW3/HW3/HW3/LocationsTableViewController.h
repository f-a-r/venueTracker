//
//  LocationsTableViewController.h
//  HW3
//
//  Created by Farzaneh Motahari on 4/5/14.
//  Copyright (c) 2014 Shahriar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LocationsTableViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>

@property (strong,nonatomic) NSMutableArray *locations;
@property (weak,nonatomic) IBOutlet UITableView *tableView;

@end
