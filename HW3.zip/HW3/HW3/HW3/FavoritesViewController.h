//
//  FavoritesViewController.h
//  HW3
//
//  Created by Farzaneh Motahari on 4/5/14.
//  Copyright (c) 2014 Shahriar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FavoritesViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>

@property (weak,nonatomic) IBOutlet UITableView *tableView;
@property (strong, nonatomic) NSArray *favorites;

@end
