//
//  Pin.m
//  HW3
//
//  Created by Farzaneh Motahari on 4/5/14.
//  Copyright (c) 2014 Shahriar. All rights reserved.
//

#import "Pin.h"

@implementation Pin

-(id)init {
    self = [super init];
    return self;
}

-(id)initWithCoordinate:(CLLocationCoordinate2D)coord title:(NSString *)name subtitle:(NSString *)adrs{
    self = [super init];
    coordinate = coord;
    title = name;
    subtitle = adrs;
    return self;
}

- (NSString *)title {
    return title;
}

- (CLLocationCoordinate2D)coordinate {
    return coordinate;
}

-(NSString *)subtitle{
    return subtitle;
}

@end
