//
//  SearchViewController.m
//  HW3
//
//  Created by Farzaneh Motahari on 4/5/14.
//  Copyright (c) 2014 Shahriar. All rights reserved.
//

#import "SearchViewController.h"
#import "COMSBaseViewController.h"
#import <COMSMapManager/COMSMapManager.h>
#import "TabBarViewController.h"

@interface SearchViewController ()

@end

@implementation SearchViewController

@synthesize locationManager = _locationManager;
@synthesize locations = _locations;
@synthesize coord = _coord;

static SearchViewController *instance; //==self pointing to searchViewController in other files.

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
    }
    return self;
}

#pragma mark - Loading methods

+ (SearchViewController *)getInstance {
    return instance;
}

- (NSString *)getQuery {
    return [_queryTextField text];
}

- (NSString *)getType {
    return [_typeTextField text];
}

- (NSString *)getRadius {
    return [_radiusTextField text];
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    NSLog(@"didFailWithError: %@", error);
    UIAlertView *errorAlert = [[UIAlertView alloc]
                               initWithTitle:@"Error" message:@"Failed to Get Your Location" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [errorAlert show];
}

#pragma mark - Core location
/*
 Automatically called by location manager because we are it's delegate
 */
-(void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations{
    CLLocation *location = [locations lastObject];
    CLLocation *currentLocation = location;
    
    if (currentLocation != nil) {
        _longitudeLabel.text = [NSString stringWithFormat:@"%.8f", currentLocation.coordinate.longitude];
        _latitudeLabel.text = [NSString stringWithFormat:@"%.8f", currentLocation.coordinate.latitude];
    }
    
    //extract the 2d coordinate for better readability
    CLLocation *loc = locations[0];
    self.coord = loc.coordinate;
    
    NSLog(@"coord=%@",loc);
    
    [_locationManager stopUpdatingLocation];
}

- (IBAction)getCurrentLocationPressed:(id)sender {
    if(!self.locationManager){
        self.locationManager = [CLLocationManager new];
    }
    self.locationManager.delegate = self;
    self.locationManager.distanceFilter = kCLDistanceFilterNone;
    self.locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    [self.locationManager startUpdatingLocation];
}

- (IBAction)searchButtonPressed:(id)sender {
    // To get query and type from searchViewController
    NSString *query = [[SearchViewController getInstance] getQuery];
    NSString *type = [[SearchViewController getInstance] getType];
    int radius = [[[SearchViewController getInstance] getRadius] intValue];
    
    // To handle multiple word queries
    query = [query stringByReplacingOccurrencesOfString:@" " withString:@"+"];
    type = [type stringByReplacingOccurrencesOfString:@" " withString:@"+"];
    
    //checking that at least query or type is entered
    if ([query isEqualToString:@""] && [type isEqualToString:@""])
    {
        dispatch_async(dispatch_get_main_queue(), ^{
            [[[UIAlertView alloc]initWithTitle:@"Empty Fields!" message:@"Both query and type were left empty!" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil]show];
        });
        [self.locationManager stopUpdatingLocation];
    }
    //if query or type is entered look for results
    else{
        //some output to check my code
        NSLog(@"INSTANCE: %@",[SearchViewController getInstance]);
        NSLog(@"%@ %@",query,type);
        
        //Your framework
        [GoogleMapManager nearestVenuesForLatLong:self.coord withinRadius:radius forQuery:query queryType:type googleMapsAPIKey:@"AIzaSyC_cSOSDYaQBNE909fefXGy7Vg1GAD8EZc" searchCompletion:^(NSMutableArray *results) {
            
            // Extracting the necessary values from JSON objects or the dictionary returned by results
            //and first checking whether the query returns any results
            if([results count] == 0){
                dispatch_async(dispatch_get_main_queue(), ^{
                    [[[UIAlertView alloc]initWithTitle:@"No results found" message:@"We couldn't find any results based upon your search criteria." delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil]show];
                });
                [self.locationManager stopUpdatingLocation];
            } else {
                for(int i = 0; i < [results count]; i++) {
                    if(!self.locations){
                        self.locations = [[NSMutableArray alloc]init];
                    }
                    [self.locations addObject:[results objectAtIndex:i]];
                }
                //sorting the location results before sending it to other view controllers
                [self sortLocations];
                dispatch_async(dispatch_get_main_queue(), ^{
                    [self.locationManager stopUpdatingLocation];
                    TabBarViewController *tabVC = [self.storyboard instantiateViewControllerWithIdentifier:@"TabBar"];
                    [tabVC setLocations:self.locations];
                    [tabVC setCoord:self.coord];
                    [self setLocations:nil];
                    [self.navigationController pushViewController:tabVC animated:YES];
                });
            }
        }];
    }
}
// Some of this code I got from Stackoverflow, in fact the idea because the usage was different there
- (void)sortLocations{
    CLLocation *myLocation = [[CLLocation alloc]initWithLatitude:self.coord.latitude longitude:self.coord.longitude];
    NSArray *orderedLocations = [self.locations sortedArrayUsingComparator:^(id a,id b) {
        NSDictionary *geometryA = [a valueForKey:@"geometry"];
        NSDictionary *locationA = [geometryA valueForKey:@"location"];
        NSString *latA = [[locationA valueForKey:@"lat"]stringValue];
        NSString *lngA = [[locationA valueForKey:@"lng"]stringValue];
        
        NSDictionary *geometryB = [b valueForKey:@"geometry"];
        NSDictionary *locationB = [geometryB valueForKey:@"location"];
        NSString *latB = [[locationB valueForKey:@"lat"]stringValue];
        NSString *lngB = [[locationB valueForKey:@"lng"]stringValue];
        
        NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc]init];
        NSNumber *numberLatA = [numberFormatter numberFromString:latA];
        NSNumber *numberLngA = [numberFormatter numberFromString:lngA];
        NSNumber *numberLatB = [numberFormatter numberFromString:latB];
        NSNumber *numberLngB = [numberFormatter numberFromString:lngB];
        
        CLLocation *locA = [[CLLocation alloc]initWithLatitude:[numberLatA doubleValue] longitude:[numberLngA doubleValue]];
        CLLocation *locB = [[CLLocation alloc]initWithLatitude:[numberLatB doubleValue] longitude:[numberLngB doubleValue]];
        
        CLLocationDistance distanceA = [locA distanceFromLocation:myLocation];
        CLLocationDistance distanceB = [locB distanceFromLocation:myLocation];
        if (distanceA < distanceB) {
            return NSOrderedAscending;
        } else if (distanceA > distanceB) {
            return NSOrderedDescending;
        } else {
            return NSOrderedSame;
        }
    }];
    self.locations = [orderedLocations mutableCopy];
    for (NSDictionary *entry in self.locations) {
        NSDictionary *geometry = [entry valueForKey:@"geometry"];
        NSDictionary *location = [geometry valueForKey:@"location"];
        NSString *lat = [[location valueForKey:@"lat"]stringValue];
        NSString *lng = [[location valueForKey:@"lng"]stringValue];
        
        NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc]init];
        NSNumber *numberLatA = [numberFormatter numberFromString:lat];
        NSNumber *numberLngA = [numberFormatter numberFromString:lng];
        
        CLLocation *locA = [[CLLocation alloc]initWithLatitude:[numberLatA doubleValue] longitude:[numberLngA doubleValue]];
        CLLocationDistance distanceA = [locA distanceFromLocation:myLocation];
        NSLog(@"distance: %f", distanceA);
    }
    NSLog(@"done");
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    instance = self;
    
    if(!self.locationManager){
        self.locationManager = [CLLocationManager new];
    }
    
    if(!self.locations){
        self.locations = [[NSMutableArray alloc]init];
    }
    
    //setting backgroun image
    UIColor *background = [[UIColor alloc] initWithPatternImage:[UIImage imageNamed:@"compass-and-map.png"]];
    self.view.backgroundColor = background;
    //we must subscribe as the delegate to the location manager
    self.locationManager.delegate = self;
    
   
}
//Code to handle disapperance of keyboard on tapping on the screen
#pragma mark - IBActions
- (IBAction)backgroundTapped{
    if([self.queryTextField isFirstResponder]){
        [self.queryTextField resignFirstResponder];
    } else if ([self.typeTextField isFirstResponder]){
        [self.typeTextField resignFirstResponder];
    } else if ([self.radiusTextField isFirstResponder]){
        [self.radiusTextField resignFirstResponder];
    }
}

#pragma mark - Memory Warning
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end

