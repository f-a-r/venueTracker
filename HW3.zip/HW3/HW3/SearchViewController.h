//
//  SearchViewController.h
//  HW3
//
//  Created by Farzaneh Motahari on 4/5/14.
//  Copyright (c) 2014 Shahriar. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>
#import "COMSBaseViewController.h"

//import the class where the CLLocationManagerDelegate protocol is implemented
@import CoreLocation;

@interface SearchViewController : UIViewController<CLLocationManagerDelegate> {

}
@property (strong, nonatomic) CLLocationManager* locationManager;
@property (strong, nonatomic) NSMutableArray *locations;
@property (nonatomic) CLLocationCoordinate2D coord;
@property (weak, nonatomic) IBOutlet UILabel *longitudeLabel;
@property (weak, nonatomic) IBOutlet UILabel *latitudeLabel;
@property (weak, nonatomic) IBOutlet UITextField *queryTextField;
@property (weak, nonatomic) IBOutlet UITextField *typeTextField;
@property (weak, nonatomic) IBOutlet UITextField *radiusTextField;

- (NSString *)getQuery;
- (NSString *)getType;
- (NSString *)getRadius;
+ (SearchViewController *)getInstance;

- (IBAction)backgroundTapped;

@end
